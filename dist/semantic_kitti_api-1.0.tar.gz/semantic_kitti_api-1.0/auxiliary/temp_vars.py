overlap_indices = None
introduced_anomaly_indices = None