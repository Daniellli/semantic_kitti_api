'''
Author: daniel
Date: 2023-03-24 19:13:38
LastEditTime: 2023-03-24 19:18:34
LastEditors: daniel
Description: 
FilePath: /semantic_kitti_api-master/setup.py
have a nice day
'''





from setuptools import setup, find_packages

setup(
    name="semantic_kitti_api",
    version="1.0",
    packages=find_packages(),
    install_requires=[
        "numpy",
    ]
)
